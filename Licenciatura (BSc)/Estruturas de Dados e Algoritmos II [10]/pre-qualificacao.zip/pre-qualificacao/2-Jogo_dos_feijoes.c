#include <stdio.h>

void criar_array(int size, int array[size])
{
    int input;

    for(int i = 0; i < size; i++)
    {
        scanf("%d", &input);
        array[i] = input;
    }
}

/*  Compara as pontuacoes dos dois jogadores
    e faz print do resultado */
void vencedor(int alex, int bela)
{
    if (alex > bela)
    {
        printf("Alex ganha com %d contra %d\n", alex, bela);
    }
    else if (alex < bela)
    {
        printf("Bela ganha com %d contra %d\n", bela, alex);
    }
    else
    {
        printf("Alex e Bela empatam a %d\n", alex);
    }    
}

void jogar(int size, int array[size])
{
    int alex_pontos = 0;
    int bela_pontos = 0;
    int i = 0;
    int j = size-1;
    int n_jogada = 1;

    /*  Compara a primeiro ultima posicao jogavel 
        do array e adiciona do seu valor a pontuaçao de cada jogador */
    while (n_jogada <= size/2)
    {
        // Jogada Alex
        if (array[i] > array[j])
        {
            alex_pontos = alex_pontos + array[i];
            i++;
        }
        else
        {
            alex_pontos = alex_pontos + array[j];
            j--;
        }

        // Jogada Bela
        if (n_jogada % 2 == 0) 
        {
            if (array[i] > array[j])
            {
                bela_pontos = bela_pontos + array[i];
                i++;
            }
            else
            {
                bela_pontos = bela_pontos + array[j];
                j--;
            }
        }
        else
        {
            if (array[i] < array[j])
            {
                bela_pontos = bela_pontos + array[i];
                i++;
            }
            else
            {
                bela_pontos = bela_pontos + array[j];
                j--;
            }
        }

        n_jogada++;
    }

    vencedor(alex_pontos, bela_pontos);
}

int main(void)
{
    int size;
    scanf("%d", &size);
    int array[size];

    criar_array(size, array);
    jogar(size, array);

    return 0;
}