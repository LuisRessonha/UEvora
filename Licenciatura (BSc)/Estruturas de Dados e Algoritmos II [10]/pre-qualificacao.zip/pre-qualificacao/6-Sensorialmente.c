#include "6-aux.h"

int ler_size()
{
    int n_sensores;
    scanf("%d", &n_sensores);

    return n_sensores;
}

void resultado(bool mensagem, int a, int z)
{
    if (mensagem == true)
        printf("yes [%d..%d]\n", a, z);

    else
        printf("no [%d..%d]\n", a, z);
}

void ler_caminho(int n_sensores, Sensores *arraySensores[n_sensores], int caminho)
{
    bool mensagem = true;
    int origen, destino, a, z;
    scanf("%d", &origen);
    a = origen;

    for (int i = 0; i < caminho; i++)
    {
        scanf("%d", &destino);
        if (check_ligacao(n_sensores, arraySensores, origen, destino) == false)
            mensagem = false;

        origen = destino;
    }
    z = destino;

    resultado(mensagem, a, z);
}

void ler_comando(int n_sensores, Sensores *arraySensores[n_sensores])
{
    char comando;
    int a, b, caminho;

    while (scanf("%c", &comando) != EOF)
    {
        switch (comando)
        {
        case '+': // add ligacao
            scanf("%d %d", &a, &b);
            add_ligacao(n_sensores, arraySensores, a, b);
            break;

        case '-': // remover ligacao
            scanf("%d %d", &a, &b);
            remover_ligacao(n_sensores, arraySensores, a, b);
            break;

        case '?':
            scanf("%d", &caminho);
            ler_caminho(n_sensores, arraySensores, caminho);
            break;

        default:
            break;
        }
    }
}

int main(void)
{
    int n_sensores = ler_size();
    Sensores *arraySensores[n_sensores];

    for (int i = 0; i < n_sensores; i++)
        arraySensores[i] = novoSensor(-1, NULL); // head da lista

    ler_comando(n_sensores, arraySensores);

    //  libertar(n_sensores, arraySensores);

    return 0;
}