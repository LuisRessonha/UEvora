#include <stdio.h>

int count_algarismos(int num)
{
    int count = 0;

/*  se o numero inserido for 0(zero)
    retorna 1 (numero de algarismos)
*/
    if (num == 0)       
        return 1;       


/*  O numero de vezes que o e feita a divisao 
    por 10(dez), ate que a parte inteira seja 0(zero),
    corresponde ao numero de algarismos necessarios
    para representar esse numero (em base 10)
*/
    while(num != 0)
    {
        num = num/10;
        count++;        // onde fica guardado o numero de 
        }               // divisoes feitas

    return count;   
}

int main(void)
{
    int num;

    scanf("%d", &num);  
    printf("%d\n", count_algarismos(num));

    return 0;
}