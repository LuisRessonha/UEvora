#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_ROUTES 10

typedef struct hashtable_item
{

    int endereco;
    short interface;
    struct hashtable_item *conflito_esq;
    struct hashtable_item *conflito_drt;
} Routes;

Routes *new_item(int endereco, short interface);
void Null_hashArray(int size, Routes *hashArray[size]);
int get_hashcode(int size, int endereco);
void inserir_conflito(int hashcode, int endereco, short interface, int size, Routes *hashArray[size]);
void inserir(int size, Routes *hashArray[size]);
short procurar_default(int size, Routes *hashArray[size]);
short procurar(int size, Routes *hashArray[size], int endereco);
