#include "5-hash.h"

void ler_routes(int n_routes, Routes *hashArray[(n_routes * 2)])
{
    Null_hashArray((n_routes * 2), hashArray);

    for (int i = 0; i < n_routes; i++)
    {
        inserir(n_routes * 2, hashArray);
    }
}

void ler_IP(int size, Routes *hashArray[size])
{
    int endereco;
    short a, b, c, d, interface;

    while (scanf("%hd.%hd.%hd.%hd", &a, &b, &c, &d) != EOF)
    {
        endereco = a * 1000000 + b * 1000 + c;

        interface = procurar(size, hashArray, endereco);

        if (interface == -1)
            printf("no route\n");

        else
            printf("%d\n", interface);
    }
}

/*
void printArray(int n_routes, Routes *hashArray[(n_routes * 2)])
{
    for (int i = 0; i < (n_routes * 2); i++)
    {
        if (hashArray[i] != NULL)
            printf("pos: %d\nendereco: %d\ninterface: %d\n\n\n", i, hashArray[i]->endereco, hashArray[i]->interface);
    }
}
*/

int main(void)
{
    int n_routes;
    scanf("%d", &n_routes);
    Routes *hashArray[(n_routes * 2)];

    ler_routes(n_routes, hashArray);
    ler_IP(n_routes * 2, hashArray);

    //printArray(n_routes, hashArray);

    return 0;
}