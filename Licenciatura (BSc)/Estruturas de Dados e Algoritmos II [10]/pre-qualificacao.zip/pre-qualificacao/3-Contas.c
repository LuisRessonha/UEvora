#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define NOME_SIZE 21
#define PONTOS_VITORIA 3
#define PONTOS_EMPATE 1
#define PONTOS_DERROTA 0


/* Estrutura de um node */
typedef struct node_equipa 
{
    char nome_equipa[NOME_SIZE];   // nome da equipa
    int pontos;
    int vitorias;
    int empates;
    int derrotas;
    int golos_marcados;
    int golos_sofridos;
} Equipa;

Equipa *new_equipa()
{
    char input[NOME_SIZE];
    scanf("%s", input);

    Equipa *equipa = malloc(sizeof(Equipa));

    strcpy(equipa->nome_equipa, input);
    equipa->pontos = 0;
    equipa->vitorias = 0;
    equipa->empates = 0;
    equipa->derrotas = 0;
    equipa->golos_marcados = 0;
    equipa->golos_sofridos = 0;
    
    return equipa;
}

void criar_array(int size, Equipa *array[size])
{
    for(int i = 0; i < size; i++)
        array[i] = new_equipa();
}

// return da posicao da equipa no array
int procurar_pos(char *equipa,int size, Equipa *array[size])
{
    for(int i = 0; i < size; i++)
    {
        if (strcmp(equipa, array[i]->nome_equipa) == 0) 
            return i;
    }
    
    return -1;
}

// faz update dos resultados
void update_golos(int pos, int marcados, int sofridos, int size, Equipa *array[size])
{
    array[pos]->golos_marcados += marcados;
    array[pos]->golos_sofridos += sofridos;
}

void vencedor(int pos, int marcados, int sofridos, int size, Equipa *array[size])
{
    array[pos]->vitorias++;
    array[pos]->pontos += PONTOS_VITORIA;
    update_golos(pos, marcados, sofridos, size, array);
}

void perdedor(int pos, int marcados, int sofridos, int size, Equipa *array[size])
{
    array[pos]->derrotas++;
    array[pos]->pontos += PONTOS_DERROTA;
    update_golos(pos, marcados, sofridos, size, array);
}

void empate(int pos, int marcados, int sofridos, int size, Equipa *array[size])
{
    array[pos]->empates++;
    array[pos]->pontos += PONTOS_EMPATE;
    update_golos(pos, marcados, sofridos, size, array);
}

// le os resultados dos jogos
void jogos(int n_jogos, int size, Equipa *array[size])
{
    char a[NOME_SIZE], b[NOME_SIZE];
    int golos_a, pos_a, golos_b, pos_b;

    for(int i = 0; i < n_jogos; i++)
    {
        scanf("%s %d - %s %d", a, &golos_a, b, &golos_b);
        pos_a = procurar_pos(a, size, array);
        pos_b = procurar_pos(b, size, array);

        if (golos_a > golos_b) // vitora a
        {
            vencedor(pos_a, golos_a, golos_b, size, array);
            perdedor(pos_b, golos_b, golos_a, size, array);
        }

        else if (golos_a < golos_b) // vitoria b
        {
            vencedor(pos_b, golos_b, golos_a, size, array);
            perdedor(pos_a, golos_a, golos_b, size, array);
        }

        else // empate
        {
            empate(pos_a, golos_a, golos_b, size, array);
            empate(pos_b, golos_b, golos_a, size, array);
        }
    }
}

int vencedor_torneio(int size, Equipa *array[size])
{
    int max_pontos = 0;
    int max_pos = 0;
    bool empatado = false;
    for(int i = 0; i < size; i++)
    {
        if (array[i]->pontos == max_pontos)
            empatado = true;

        if (array[i]->pontos > max_pontos) 
        {
            max_pontos = array[i]->pontos;
            max_pos = i;
            empatado = false;
        }
    }

    if (empatado == true)
        return -1;
    
    else
        return max_pos;
}

void resultado(int size, Equipa *array[size])
{
    int torneio = vencedor_torneio(size, array);

    if (torneio == -1)
        printf("torneio sem vencedora\n");
    
    else
    {
        printf("a vencedora foi %s, com %d ponto(s)\n", 
                    array[torneio]->nome_equipa, array[torneio]->pontos);
        printf("ganhou %d jogo(s), empatou %d jogo(s) e perdeu %d jogo(s)\n",
                    array[torneio]->vitorias, array[torneio]->empates, array[torneio]->derrotas);
        printf("marcou %d golo(s) e sofreu %d golo(s)\n",
                    array[torneio]->golos_marcados, array[torneio]->golos_sofridos);
    }
}

void libertar(int size, Equipa *array[size])
{
    for(int i = 0; i < size; i++)
        free(array[i]);
}

int main(void)
{
    int n_equipas, n_jogos;
    scanf("%d %d", &n_equipas, &n_jogos);
    

    criar_array(n_equipas, array);
    jogos(n_jogos, n_equipas, array);
    resultado(n_equipas, array);

    libertar(n_equipas, array);
    return 0;
}