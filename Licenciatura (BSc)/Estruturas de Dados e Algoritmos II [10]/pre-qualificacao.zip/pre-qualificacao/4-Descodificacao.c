#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define MAX_SIZE 1101

void letras(int size, bool alfabeto[size])
{
    for(int i = 0; i < size; i++)
        alfabeto[i] = false;
}

void decode(char input[MAX_SIZE])
{
    int size = 26;
    bool alfabeto[size];
    letras(size, alfabeto);

    int pos = 0;

    while(input[pos] != '\0')
    {
        for(int i = 0; i < size; i++)
        {
            char c = i+97;
            if (input[pos] == c)
            {
                if (alfabeto[i] == true)
                {
                    letras(size, alfabeto);    
                    printf("%c",c);
                }
                else
                    alfabeto[i] = true;

                break;
            }   
        }
        pos++;
    }
    printf("\n");
}

int main(void)
{
    char input[MAX_SIZE];

    while(scanf("%s", input) != EOF)     
        decode(input);
    
    return 0;
}