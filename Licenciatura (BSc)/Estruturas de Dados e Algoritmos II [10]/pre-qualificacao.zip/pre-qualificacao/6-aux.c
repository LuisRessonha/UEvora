#include "6-aux.h"

Sensores *novoSensor(int id_sensor, Sensores *seguinte)
{
    Sensores *item = malloc(sizeof(Sensores));

    item->id_sensor = id_sensor;
    item->next = seguinte;

    return item;
}

void add_ligacao(int n_sensores, Sensores *arraySensores[n_sensores], int a, int b)
{
    bool inserido = false;
    Sensores *anterior = arraySensores[a];
    Sensores *atual = arraySensores[a];

    while (inserido == false)
    {
        if (atual->id_sensor == b)
            break; //o sensor ja foi inserido

        else if (atual->id_sensor > b) //inserir meio da lista
        {
            anterior->next = novoSensor(b, atual);
            inserido = true;
        }

        else if (atual->next == NULL) //inserir no fim da lista
        {
            atual->next = novoSensor(b, NULL);
            inserido = true;
        }

        else if (atual->id_sensor < b) //avanca
        {
            anterior = atual;
            atual = atual->next;
        }
    }
}

void remover_ligacao(int n_sensores, Sensores *arraySensores[n_sensores], int a, int b)
{
    bool removido = false;
    Sensores *anterior = arraySensores[a];
    Sensores *atual = arraySensores[a];

    while (removido == false)
    {
        if (atual->id_sensor == b) //remover
        {
            if (atual->next == NULL)
                anterior->next = NULL;
            else
                anterior->next = atual->next;

            free(atual);
            removido = true;
        }
        else if (atual->id_sensor < b && atual->next != NULL) //avanca na lista
        {
            anterior = atual;
            atual = atual->next;
        }
        else
            break;
    }
}

bool check_ligacao(int n_sensores, Sensores *arraySensores[n_sensores], int a, int b)
{
    if (arraySensores[a]->next != NULL)
    {
        Sensores *atual = arraySensores[a];

        while (atual->id_sensor <= b)
        {
            if (atual->id_sensor == b)
                return true;

            if (atual->next != NULL)
                atual = atual->next;

            else
                break;
        }
    }

    return false;
}

/* o malloc nao esta a funcionar nao sei porque - rever mais tarde
void libertar(int size, Sensores *arraySensores[size])
{
    for (int i = 0; i < size; i++)
    {
        Sensores *anterior = arraySensores[i];
        Sensores *atual = arraySensores[i];
        while (atual != NULL)
        {
            atual = atual->next;
            free(anterior);
            anterior = atual;
        }

        //free(arraySensores[i]);
    }
}
*/