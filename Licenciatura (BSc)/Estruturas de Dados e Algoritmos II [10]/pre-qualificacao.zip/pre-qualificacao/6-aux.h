#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

typedef struct sensores_no
{
    int id_sensor;
    struct sensores_no *next;

} Sensores;

Sensores *novoSensor(int id_sensor, Sensores *atual);

void add_ligacao(int n_sensores, Sensores *arraySensores[n_sensores], int a, int b);
void remover_ligacao(int n_sensores, Sensores *arraySensores[n_sensores], int a, int b);
bool check_ligacao(int n_sensores, Sensores *arraySensores[n_sensores], int a, int b);
//void libertar(int size, Sensores *arraySensores[size]);