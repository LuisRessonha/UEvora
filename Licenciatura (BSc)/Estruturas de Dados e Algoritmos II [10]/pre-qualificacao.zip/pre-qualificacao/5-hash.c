#include "5-hash.h"

Routes *new_item(int endereco, short interface)
{
    Routes *item = malloc(sizeof(Routes));

    item->endereco = endereco;
    item->interface = interface;
    item->conflito_esq = NULL;
    item->conflito_drt = NULL;

    return item;
}

void Null_hashArray(int size, Routes *hashArray[size])
{
    for (int i = 0; i < size; i++)
        hashArray[i] = NULL;
}

int get_hashcode(int size, int endereco)
{
    int hashcode = (endereco % size);

    return hashcode;
}

void inserir_conflito(int hashcode, int endereco, short interface, int size, Routes *hashArray[size])
{
    bool inserido = false;
    Routes *atual = hashArray[hashcode];

    while (inserido == false)
    {
        if (endereco < atual->endereco)
        {
            // verificar esq
            if (atual->conflito_esq == NULL)
            {
                atual->conflito_esq = new_item(endereco, interface);
                inserido = true;
            }
            else
                atual = atual->conflito_esq;
        }

        else
        {
            // verificar drt
            if (atual->conflito_drt == NULL)
            {
                atual->conflito_drt = new_item(endereco, interface);
                inserido = true;
            }
            else
                atual = atual->conflito_drt;
        }
    }
}

void inserir(int size, Routes *hashArray[size])
{
    int endereco;
    short a, b, c, d, interface;

    scanf("%hd.%hd.%hd.%hd %hd", &a, &b, &c, &d, &interface);
    endereco = a * 1000000 + b * 1000 + c;

    int hashcode = get_hashcode(size, endereco);

    if (hashArray[hashcode] == NULL)
        hashArray[hashcode] = new_item(endereco, interface);

    else
        inserir_conflito(hashcode, endereco, interface, size, hashArray);
}

short procurar_default(int size, Routes *hashArray[size])
{
    bool loop = true;
    Routes *atual = hashArray[0];

    while (loop == true)
    {
        if (atual->endereco == 0)
            return atual->interface;
        else if (atual->conflito_esq != NULL)
            atual = atual->conflito_esq;
        else
            break;
    }
    return -1;
}

short procurar(int size, Routes *hashArray[size], int endereco)
{
    int hashcode = get_hashcode(size, endereco);

    if (hashArray[hashcode] != NULL)
    {
        bool loop = true;
        Routes *atual = hashArray[hashcode];

        while (loop == true)
        {
            if (atual->endereco == endereco)
                return atual->interface;
            else if (endereco < atual->endereco && atual->conflito_esq != NULL)
                atual = atual->conflito_esq;
            else if (endereco > atual->endereco && atual->conflito_drt != NULL)
                atual = atual->conflito_drt;
            else
                break;
        }
    }

    return procurar_default(size, hashArray);
}