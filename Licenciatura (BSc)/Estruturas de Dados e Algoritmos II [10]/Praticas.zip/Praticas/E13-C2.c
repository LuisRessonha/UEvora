#include <stdio.h>

int bin_recursiva(int num)
{
}

void binario(int num)
{
}

void neg_bin(int num)
{
}

int main(void)
{
    binario(-10);
    neg_bin(-10);
    
    return 0;
}