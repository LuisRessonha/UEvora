#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <math.h>


// Feito
typedef struct data_nif {
	int nif;
	float geral;
	float saude;
	float educ;
	float alim;	
	char combo;
	int combo_par;
} data;

// Feito
data *data_new(int nif){
	data *dt= malloc(sizeof(data));
	dt->nif = nif;
	dt->geral = 0;
	dt->saude = 0;
	dt->educ = 0;
	dt->alim = 0;
	dt->combo = 'I';
	dt->combo_par = -1;

	return dt;
}

// Feito
void node_destroy(data *node){
	free(node);
}

// Feito
void add_nif(int n, data *array[n]){
	int x;
	int index = 0;

	// Coloca todas as posicoes do array a NULL
	for (int j = 0; j < n; ++j) {
		array[j]=NULL;
	}

	// Faz corresponder cada nif a uma posição no array
	// e cada posição a um node
	for (int i = 0; i < n; i++){ 
		scanf("%d", &x);
		data *node = data_new(x);
		index = x%n;

		if (array[index] == NULL){
			array[index] = node;
		}
		else{ //if (array[index] != NULL){
			int k = 0;
			while(k != n){
				index++;
				if (array[index] == NULL){
					array[index] = node;
					break;
				}
				
			//for (int k = index; k < n; ++k){
			//	if (k == n-1){
			//		k=0;
			//	}

				if (index == n -1)	{
					index = 0;
				}
			}
		}
	}
}

// Feito
int procurar_nif(int n, data *array[n], int nif){
	int index;
	int count = 0;

	if (n == 0){
		index = -1;
		return index;
	}

	index = nif%n;

	while (array[index]->nif != nif){
		index = index + 1;
		if (index == n){
			index = 0;
		}
		
		
		if (count == n){
			// nif sem info
			index = -1;
			return index;
		}
		count++;

	}

	return index;
}

// Feito
void combinar_nif(int n, data *array[n], int c){
	int c1 = 0;
	int c2 = 0;
	int nif_c1 = 0;
	int nif_c2 = 0;

	for (int i = 0; i < c; ++i) {
		scanf(" %d %d", &c1 ,&c2);
		nif_c1 = procurar_nif(n, array, c1);
		nif_c2 = procurar_nif(n, array, c2);

		array[nif_c1]->combo = 'C';
		array[nif_c2]->combo = 'C';

		array[nif_c1]->combo_par = array[nif_c2]->nif;
		array[nif_c2]->combo_par = array[nif_c1]->nif;
	}
}

// Feito
void add_data(int n, data *array[n], char cod, int nif, float valor){
	int index, index_par, nif_par;

	if (cod == 'g'){
		index = procurar_nif(n, array, nif);
		if (index != -1){

			array[index]->geral = array[index]->geral + valor;

			// Adiciona tambem no nif combinado
			if (array[index]->combo == 'C'){
				nif_par = array[index]->combo_par;
				index_par = procurar_nif(n, array, nif_par);
				array[index_par]->geral = array[index]->geral;
			}
		}
	}

	// if s
	if (cod == 's'){
		index = procurar_nif(n, array, nif);
		if (index != -1){

			array[index]->saude = array[index]->saude + valor;

			// Adiciona tambem no nif combinado
			if (array[index]->combo == 'C'){
				nif_par = array[index]->combo_par;
				index_par = procurar_nif(n, array, nif_par);
				array[index_par]->saude = array[index]->saude;
			}
		}
	}

	// if e
	if (cod == 'e'){
		index = procurar_nif(n, array, nif);
		if (index != -1){

			array[index]->educ = array[index]->educ + valor;

			// Adiciona tambem no nif combinado
			if (array[index]->combo == 'C'){
				nif_par = array[index]->combo_par;
				index_par = procurar_nif(n, array, nif_par);
				array[index_par]->educ = array[index]->educ;
			}
		}
	}

	// if a (tambem adiciona no geral)
	if (cod == 'a'){
		index = procurar_nif(n, array, nif);
		if (index != -1){

			array[index]->alim = array[index]->alim + valor;
			array[index]->geral = array[index]->geral + valor;

			// Adiciona tambem no nif combinado
			if (array[index]->combo == 'C'){
				nif_par = array[index]->combo_par;
				index_par = procurar_nif(n, array, nif_par);
				array[index_par]->alim = array[index]->alim;
				array[index_par]->geral = array[index]->geral;
			}
		}
	}
}

// Feito
void print_inf(int n, data *array[n], int nif){
	int index;
	index = procurar_nif(n, array, nif);
	
	if (index == -1){
		printf("contribuinte sem informacao: %09d\n", nif);
	}
	else{
	printf("%09d [%c] geral%9.2f, saude%9.2f, educ.%9.2f, alim.%9.2f\n", 
		array[index]->nif, array[index]->combo, array[index]->geral, 
		array[index]->saude, array[index]->educ, array[index]->alim);
	}
}

// Feito
void info(int n, data *array[n]){
	char cod;
	int nif;
	float valor;
	while(scanf(" %s", &cod) != EOF){
		if (cod == '?') {
			scanf(" %d", &nif);
			print_inf(n, array, nif); //Procurar
		}
		else {
			scanf(" %d %f", &nif, &valor);
			add_data(n, array, cod, nif, valor);
		}
	}
}


int main(void){
	int n; // Nº de NIF's (tamanho array)
	scanf(" %d", &n);
	data *array[n];

	if (n > 0 && n <= 500000){
		// inserir n NIF's 
		add_nif(n, array); 
	}

	int c;
	scanf(" %d", &c);

	if (c != 0){
		// conbinar pares de nif
		combinar_nif(n, array, c);
	}
	
	// pesquisar ou adicionar informacoa
	info(n, array);

	// limpar a memoria
	for (int i = 0; i < n; ++i){
		node_destroy(array[i]);
	}

//	free(array);

	return 0;
}