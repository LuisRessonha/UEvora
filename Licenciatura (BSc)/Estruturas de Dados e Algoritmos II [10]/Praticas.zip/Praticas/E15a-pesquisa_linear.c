#include <stdio.h>

#define SIZE 500000

void preencher(int s, int array[s])
{
    for(int i = 0; i < SIZE; i++)
    {
        array[i] = 2 *i;
    }
}

int procura(int n, int s, int array[s])
{
    for (int pos = 1; pos <= s; ++pos)
    {
        if (array[pos] == n)
            return pos;
    }
    return -1;
}

int main(void)
{
    int array[SIZE];
    preencher(SIZE, array);  //  i

    int n, pos;
    scanf(" %d", &n);
    pos = (procura(n, SIZE, array)); // ii

    if (pos == -1)
        printf("Não encontrou %d\n", n);

    else if (array[pos] != 2 *pos) 
        printf("Encontrou %d na posição errada: %d\n", n, pos);

    else
        printf("Encontrou %d na posição %d\n", n, pos);

    printf("Pos 0: %d\n", array[0]);

    return 0;
}