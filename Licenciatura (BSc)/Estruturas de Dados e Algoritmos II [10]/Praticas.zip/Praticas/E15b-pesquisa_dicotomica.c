#include <stdio.h>

#define SIZE 500000

void preencher(int s, int array[s])
{
    for(int i = 0; i < SIZE; i++)
    {
        array[i] = 2 *i;
    }
}

int procura(int n, int s, int array[s])
{
    return procura_binaria(n, array, 0, s-1);
}

int procura_binaria(int n, int array[], int i, int f)
{
    int m = ((i + f)/2);     // Ponto medio

    if(i > f)
        return -1;

    if(n < array[m])
        return procura_binaria(n, array, i, m - 1);

    if(n > array[m])
        return procura_binaria(n, array, m + 1, f);

    // if (n == array[m])
    return m;
}

int main(void)
{
    int array[SIZE];
    preencher(SIZE, array);  //  i

    int n, pos;
    scanf(" %d", &n);
    pos = (procura(n, SIZE, array)); // ii

    if (pos == -1)
        printf("Não encontrou %d\n", n);

    else if (array[pos] != 2 *pos) 
        printf("Encontrou %d na posição errada: %d\n", n, pos);

    else
        printf("Encontrou %d na posição %d\n", n, pos);

    return 0;
}