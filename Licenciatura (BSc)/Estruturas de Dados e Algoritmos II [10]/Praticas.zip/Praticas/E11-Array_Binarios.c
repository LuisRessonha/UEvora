#include <stdio.h>

void binario(int num)
{
    int dec = num;

    if (num < 0)
        num = 0 - num;
    
    int bin[(num^2)], i;

    for(i = 0; num > 0; i++)
    {
    bin[i] = num%2;
    num = num/2;
    }
    
    printf("%d = ", dec);

    if (dec < 0){
        printf("-");
    }

    for(i = (i-1); i >= 0; i--)
    {
        printf("%d", bin[i]);
    }

    printf("\n");
}

int main(void)
{
    binario(10);
    binario(-170);
    return 0;
}