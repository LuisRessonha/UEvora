#include <stdio.h>

// adicionar casas ao mapa
void add_casa(int size, char mapa[size][size]){
    char input;
    for (int linha = 0; linha < size; linha++){
        for (int coluna = 0; coluna < size; coluna++){
            scanf(" %c", &input);
            mapa[linha][coluna] = input;
        }
    }
}

// verificar se uma casa tem vizinhos
void vizinhos(int size, char mapa[size][size]){
    int size_ten = size*size;
    int casa_iso[2][size_ten]; // matriz onde sao guardadas as coordenadas
    int pos_iso = 0; // numero de casas isoladas
    int max = size - 1; // valor maximo da coordenada

    int a = 0;
    int b = 1;


    for (int linha = 0; linha < size; linha++){
        for (int coluna = max; coluna >= 0; coluna--){

            if (mapa[linha][coluna] == 'x' || mapa[linha][coluna] == 'X'){

                // uma unica posicao e igual a X
                if (size == 1) {
                    casa_iso[a][pos_iso] = size - linha;
                    casa_iso[b][pos_iso] = coluna + 1;

                    pos_iso++;
                }
                // Canto superior esquerdo
                if (linha == 0 && coluna == 0){
                    if (mapa[linha + 1][coluna] == '.' &&
                        mapa[linha][coluna + 1] == '.' &&
                        mapa[linha + 1][coluna + 1] == '.'){

                        casa_iso[a][pos_iso] = size - linha;
                        casa_iso[b][pos_iso] = coluna + 1;

                        pos_iso++;
                    }
                }

                // Canto superior direito
                else if (linha == 0 && coluna == size-1){
                    if (mapa[linha + 1][coluna] == '.' &&
                        mapa[linha][coluna - 1] == '.' &&
                        mapa[linha + 1][coluna - 1] == '.'){

                        casa_iso[a][pos_iso] = size - linha;
                        casa_iso[b][pos_iso] = coluna + 1;

                        pos_iso++;
                    }
                }

                // Canto inferior direito
                else if (linha == size-1 && coluna == size-1){
                    if (mapa[linha - 1][coluna] == '.' &&
                        mapa[linha][coluna - 1] == '.' &&
                        mapa[linha - 1][coluna - 1] == '.'){

                        casa_iso[a][pos_iso] = size - linha;
                        casa_iso[b][pos_iso] = coluna + 1;

                        pos_iso++;
                    }
                }

                // Canto inferior esquerdo
                else if (linha == size-1 && coluna == 0){
                    if (mapa[linha - 1][coluna] == '.' &&
                        mapa[linha][coluna + 1] == '.' &&
                        mapa[linha - 1][coluna + 1] == '.'){

                        casa_iso[a][pos_iso] = size - linha;
                        casa_iso[b][pos_iso] = coluna + 1;

                        pos_iso++;
                    }
                }

                // Linha 0 (primeira linha)
                else if (linha == 0){
                    if (mapa[linha][coluna - 1] == '.' &&
                        mapa[linha][coluna + 1] == '.' &&
                        mapa[linha + 1][coluna - 1] == '.' &&
                        mapa[linha + 1][coluna] == '.' &&
                        mapa[linha + 1][coluna + 1] == '.'){

                        casa_iso[a][pos_iso] = size - linha;
                        casa_iso[b][pos_iso] = coluna + 1;

                        pos_iso++;
                    }
                }

                // Linha size-1 (ultima)
                else if (linha == size-1){
                    if (mapa[linha][coluna - 1] == '.' &&
                        mapa[linha][coluna + 1] == '.' &&
                        mapa[linha - 1][coluna - 1] == '.' &&
                        mapa[linha - 1][coluna] == '.' &&
                        mapa[linha - 1][coluna + 1] == '.'){

                        casa_iso[a][pos_iso] = size - linha;
                        casa_iso[b][pos_iso] = coluna + 1;

                        pos_iso++;
                    }
                }

                // coluna 0 (primeira coluna)
                else if (coluna == 0){
                    if (mapa[linha - 1][coluna] == '.' &&
                        mapa[linha - 1][coluna + 1] == '.' &&
                        mapa[linha][coluna + 1] == '.' &&
                        mapa[linha + 1][coluna] == '.' &&
                        mapa[linha + 1][coluna + 1] == '.'){

                        casa_iso[a][pos_iso] = size - linha;
                        casa_iso[b][pos_iso] = coluna + 1;

                        pos_iso++;
                    }
                }

                // coluna size-1 (ultima coluna)
                else if (coluna == size-1){
                    if (mapa[linha - 1][coluna] == '.' &&
                        mapa[linha - 1][coluna - 1] == '.' &&
                        mapa[linha][coluna - 1] == '.' &&
                        mapa[linha + 1][coluna] == '.' &&
                        mapa[linha + 1][coluna - 1] == '.'){

                        casa_iso[a][pos_iso] = size - linha;
                        casa_iso[b][pos_iso] = coluna + 1;

                        pos_iso++;
                    }
                }

                // centro do mapa
                else{
                    if (mapa[linha - 1][coluna - 1] == '.' &&
                        mapa[linha - 1][coluna] == '.' &&
                        mapa[linha - 1][coluna + 1] == '.' &&
                        mapa[linha][coluna - 1] == '.' &&
                        mapa[linha][coluna + 1] == '.' &&
                        mapa[linha + 1][coluna - 1] == '.' &&
                        mapa[linha + 1][coluna] == '.' &&
                        mapa[linha + 1][coluna + 1] == '.'){

                        casa_iso[a][pos_iso] = size - linha;
                        casa_iso[b][pos_iso] = coluna + 1;

                        pos_iso++;
                    }
                }
            }   
        }
    }

    if (pos_iso == 0) {
        printf("nao existem habitacoes isoladas\n");
    }

    else{
        printf("existem %d habitacoes isoladas:", pos_iso);

        for (int i = pos_iso - 1; i >= 0; i--) {
            printf(" (%d,%d)", casa_iso[a][i], casa_iso[b][i]);
        }
        printf("\n");
    }
}

int main(){
    int size; // tamanho do mapa
    scanf(" %d\n", &size);

    char mapa[size][size];

    if (size > 0) {
        add_casa(size, mapa);
        vizinhos(size, mapa);
    }
    else {
        printf("nao existem habitacoes isoladas\n");
    }
    return 0;
}