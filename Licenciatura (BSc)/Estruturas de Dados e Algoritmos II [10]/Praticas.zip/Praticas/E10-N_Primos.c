#include <stdio.h>

void n_primos(int min, int max)
{
    for(int i = min; i < max; i++)
    {
        if(check_primos(i) > 2)
            continue;

        else
            printf("%d é primo\n", i);
    }
}

int check_primos(int num)
{
    int j, div = 0;

    for(j = 1; j <= num; j++)
    {
        if((num%j) == 0)
            div++;
        
        if (div > 2)
            return div;
    }
    return div;            
}

int main(void)
{
    n_primos(555, 777);
    return 0;
}