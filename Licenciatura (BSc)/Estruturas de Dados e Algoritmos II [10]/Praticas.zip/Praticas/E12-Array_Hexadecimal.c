#include <stdio.h>
#include <stdlib.h>

void hexadecimal(int num)
{
    int dec = num;

    if (num < 0)
        num = 0 - num;
    
    char hexa[num];
    int i = 0;
    char str[1024];

    while(num != 0)
    {
        int resto = num%16;

        switch (resto)
        {
            case 10:
                hexa[i] = 'A';
                i++;
                break;

            case 11:
                hexa[i] = 'B';
                i++;
                break;
            
            case 12:
                hexa[i] = 'C';
                i++;
                break;
            
            case 13:
                hexa[i] = 'D';
                i++;
                break;
            
            case 14:
                hexa[i] = 'E';
                i++;
                break;
            
            case 15:
                hexa[i] = 'F';
                i++;
                break;

            default:
                hexa[i] = resto + '0';
                i++; 
                break;
        }

        num = num/16;
    }

    printf("%d = ", dec);

    if (dec < 0){
        printf("-");
    }

    if (dec == 0){
        printf("0");
    }

    for(int j=i-1; j>=0; j--)
    {
        printf("%c", hexa[j]);
    }

    printf("(16)\n");
}

int main(void)
{
    hexadecimal(28);

    return 0;
}