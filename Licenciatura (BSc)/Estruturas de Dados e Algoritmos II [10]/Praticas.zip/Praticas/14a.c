#include <stdio.h>

















int main() {
	const int TAMANHO = 50000;
	int pos = 0;
	int array50[TAMANHO];

	for (pos = 0; pos < TAMANHO; pos++){
		array50[pos]=(pos+1)*2;
	}

	printf("%d\n", array50[0]);
}