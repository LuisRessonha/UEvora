#include <stdio.h>
#include <stdlib.h>

// feito
typedef struct informacao {
	unsigned long instante;
	int latitude_g;
	int latitude_min;
	int latitude_seg;

	int longitude_g;
	int longitude_min;
	int longitude_seg;

	struct informacao *next;
}info;

//feito
typedef struct inicio_lista {
	info *inicio;
	info *fim;
}lista;

// feito
info *new_info(){
	info *inf = malloc(sizeof(info));
	inf->instante = 0;
	inf->latitude_g = 0;
	inf->latitude_min = 0;
	inf->latitude_seg = 0;
	inf->longitude_g = 0;
	inf->longitude_min = 0;
	inf->longitude_seg = 0;
	inf->next = NULL;

	return inf;
}

//feito
lista *lista_new(){
	lista *list = malloc(sizeof(lista));
	list->inicio = new_info();
	list->fim = list->inicio;

	return list;
}

// libertar memoria
void node_destroy(int max_size, int i, lista *array[max_size]){
	info *atual = array[i]->inicio;
	info *seguinte;
	while (atual != NULL){
		seguinte = atual->next;
		free(atual);
		atual = seguinte;
	}
}
void list_destroy(int max_size, int i, lista *array[max_size]){
	node_destroy(max_size, i, array);
	free(array[i]);
}
////////


//feito
void add_inf(int max_size, lista *array[max_size], int suspeito, unsigned long instante,
									int latitude_g, int latitude_min, 
									int latitude_seg, int longitude_g, 
									int longitude_min, int longitude_seg){
	info *data = new_info();
	data->instante = instante;
	data->latitude_g = latitude_g;
	data->latitude_min = latitude_min;
	data->latitude_seg = latitude_seg;
	data->longitude_g = longitude_g;
	data->longitude_min = longitude_min;
	data->longitude_seg = longitude_seg;

	if (array[suspeito]->inicio == array[suspeito]->fim){
		array[suspeito]->inicio->next = data;
		array[suspeito]->fim = data;
	}
	else{
		array[suspeito]->fim->next = data;
		array[suspeito]->fim = data;
	}
}


// comparar_inf e output
void comparar_inf(int max_size, lista *array[max_size]){
	int suspeito_A, suspeito_B;
	while (scanf(" %d %d", &suspeito_A, &suspeito_B) != EOF){
		int n_encontrar = 0;

		if (array[suspeito_A] == NULL && array[suspeito_B] == NULL){
			printf("+ sem dados sobre os suspeitos %05d e %05d\n", suspeito_A, suspeito_B);
		}

		else if (array[suspeito_A] == NULL) {
			printf("+ sem dados sobre o suspeito %05d\n", suspeito_A);
		}
		else if (array[suspeito_B] == NULL) {
			printf("+ sem dados sobre o suspeito %05d\n", suspeito_B);
		}

/////////////////////////////////////////////////////////////////////////
		else {
			info *atual_A = array[suspeito_A]->inicio;
			info *atual_B = array[suspeito_B]->inicio;
			atual_A = atual_A->next;
			atual_B = atual_B->next;
			int n_print = 0;
			n_encontrar = 1;

			while (atual_A->next != NULL || atual_B != NULL){
				//n_encontrar = 1;
				unsigned long instante_A = atual_A->instante;
				unsigned long instante_B = atual_B->instante;

				int latitude_g_A = atual_A->latitude_g;
				int latitude_min_A = atual_A->latitude_min;
				int latitude_seg_A = atual_A->latitude_seg;
				int longitude_g_A = atual_A->longitude_g;
				int longitude_min_A = atual_A->longitude_min;
				int longitude_seg_A = atual_A->longitude_seg;

				int latitude_g_B = atual_B->latitude_g;
				int latitude_min_B = atual_B->latitude_min;
				int latitude_seg_B = atual_B->latitude_seg;
				int longitude_g_B = atual_B->longitude_g;
				int longitude_min_B = atual_B->longitude_min;
				int longitude_seg_B = atual_B->longitude_seg;

				if (instante_A == instante_B) {
					if (latitude_g_A == latitude_g_B &&
						latitude_min_A == latitude_min_B &&
						latitude_seg_A == latitude_seg_B &&
						longitude_g_A == longitude_g_B &&
						longitude_min_A == longitude_min_B &&
						longitude_seg_A == longitude_seg_B){

						n_encontrar = 0;

						if (n_print == 0){
							printf("+ %05d e %05d podem ter-se encontrado em:\n", suspeito_A, suspeito_B);
							printf("%lu %d %d' %d\" %d %d' %d\"\n", instante_A, latitude_g_A, 
															latitude_min_A, latitude_seg_A,
															longitude_g_A, longitude_min_A,
															longitude_seg_A);
							n_print = 1;
						}
						else if (n_print != 0){
							printf("%lu %d %d' %d\" %d %d' %d\"\n", instante_A, latitude_g_A, 
															latitude_min_A, latitude_seg_A,
															longitude_g_A, longitude_min_A,
															longitude_seg_A);
						}

						if (atual_A->next == NULL) break;
						atual_A = atual_A->next;
						}
					else{
					if (atual_A->next == NULL) break;
						atual_A = atual_A->next;
					}
				}

				else if (instante_A > instante_B) {
					if (atual_B->next == NULL) break;
					atual_B = atual_B->next;
				}
				else if (instante_A < instante_B) {
					if (atual_A->next == NULL) break;
					atual_A = atual_A->next;
				}
			}
		}
		if (n_encontrar == 1) {
			printf("+ %05d e %05d nunca se encontraram (aparentemente)\n", suspeito_A, suspeito_B);
		}
	}
/////////////////////////////////////////////////////////////////////////
}
// print
void print_interesse(int suspeito_A, int suspeito_B, unsigned long instante, 
						int latitude_g, int latitude_min, int latitude_seg, 
						int longitude_g, int longitude_min, int longitude_seg){
}



int main(void){
	int max_size = 100000;

	lista *array[max_size];

	// Coloca todas as posicoes do array a NULL
	for (int i = 0; i < max_size; i++) {
		array[i]=NULL;
	}

	// inserir info nas listas
	int suspeito = 1;
	unsigned long instante;
	int latitude_g, latitude_min, 
		latitude_seg, longitude_g, 
		longitude_min, longitude_seg;

	while (suspeito != 00000){
		scanf(" %d", &suspeito);
		if (suspeito == 00000) break;

		scanf(" %lu %d %d' %d\" %d %d' %d\"\n",&instante, &latitude_g, 
									&latitude_min, &latitude_seg, &longitude_g, 
									&longitude_min, &longitude_seg);
		if (array[suspeito] == NULL){
			array[suspeito] = lista_new();
		}
		add_inf(max_size, array, suspeito, instante,
									latitude_g, latitude_min, 
									latitude_seg, longitude_g, 
									longitude_min, longitude_seg);
	}


	// comparar inf
	comparar_inf(max_size, array);


	// libertar memoria
	for (int i = 0; i < max_size; ++i) {
		if (array[i] != NULL) {
			list_destroy(max_size, i, array);
		}
	}
	return 0;
}