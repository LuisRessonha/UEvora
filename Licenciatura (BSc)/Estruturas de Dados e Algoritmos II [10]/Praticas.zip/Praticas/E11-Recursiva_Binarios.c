#include <stdio.h>

int bin_recursiva(int num)
{
    if(num != 0)
        bin_recursiva((num/2));

    int resto = num%2;
    printf("%d", resto);

    return 0;
}

void binario(int num)
{
    printf("%d = ", num);
    
    if (num < 0){
        printf("-");
    }
    if (num < 0)
        num = 0 - num;

    bin_recursiva(num);

    printf("\n");
}

int main(void)
{
    binario(-10);
    binario(0);
    binario(-170);
    
    return 0;
}