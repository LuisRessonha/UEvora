// Fibonacci Recursivamente
#include <stdio.h>

#define N_ELEMENTOS 45

int fibonacci(int n)
{
  if(n == 0)
    return 0;
   
  else if(n == 1) 
    return 1;
   
  else
    return (fibonacci(n-1) + fibonacci(n-2));
}

int main(void)
{
  for(int i = 0; i < N_ELEMENTOS; i++)
  {
    printf("%d ",fibonacci(i));            
  }

  printf("\n");

  return 0;
}