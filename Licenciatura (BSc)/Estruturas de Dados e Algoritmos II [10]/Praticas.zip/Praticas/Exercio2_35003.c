#include <stdio.h>

// Preencher os arrays com uma sequencia de numeros
void array(int x, int arrayN[x]) {

	int y;

	for (int i = 0; i < x; i++){
		scanf("%d", &y);
		arrayN[i]=y;
	}
}

/* 	Fazer corresponder cada valor da segunda da segunda sequencia
	a uma posicao da primeira sequencia 
	e escrever o valor da mesma da seguite forma
	valor @ <posição> = <valor>
*/
void output(int n, int arrayN[n], int s, int arrayS[s]){
	for (int pos=0; pos < s; pos++){
		int num=arrayS[pos];
		if (num<=n && num>0){
			printf("valor @ %d = %d\n", num, arrayN[num-1]);
		}
		else{
			printf("valor @ %d = -\n", num);
		}
	}
}

int main(void){
	// Array 1
	int n; //tamanho arrayN
	scanf("%d", &n);
	int arrayN[n];
	array(n, arrayN);

	// Array 2
	int s; //tamanho arrayS
	scanf("%d", &s);
	int arrayS[s];
	array(s, arrayS);

	output(n, arrayN, s, arrayS);
}






