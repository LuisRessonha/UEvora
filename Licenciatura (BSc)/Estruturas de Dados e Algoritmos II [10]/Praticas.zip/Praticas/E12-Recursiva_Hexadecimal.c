#include <stdio.h>

int hex_recursiva(int num)
{
    if(num != 0)
    {
        hex_recursiva((num/16));
        
        int resto = num%16;
        
        if(resto >= 10)
            printf("%c", (char)(resto + 55));
        
        else
            printf("%d", resto);

        return 0;
    }
    
    else
        return 0;
}

void hexadecimal(int num)
{
    printf("%d = ", num);
    
    if (num < 0){
        printf("-");
    }
    if (num < 0)
        num = 0 - num;

    if(num == 0)
        printf("%d", num);

    else
    {
        hex_recursiva(num);
    }
    

    printf("\n");
}

int main(void)
{
    hexadecimal(5000);
    hexadecimal(-28);

    return 0;
}