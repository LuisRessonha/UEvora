#include <stdio.h>

void triangulo(int size)
{
  for (int i = 1; i <= size; ++i)
  {
    int j;

    for (j = 1; j < i; ++j)
      printf("%3d ", i * j);

    printf("%3d\n", i * j);
  }
}

int main(void)
{
  triangulo(10);
  return 0;
}