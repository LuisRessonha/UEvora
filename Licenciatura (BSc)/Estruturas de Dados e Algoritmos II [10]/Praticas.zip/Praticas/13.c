#include <stdio.h>

void ler_escrever_inteiro() {
	int n;
	printf("Insira um numero inteiro: ");
	scanf("%d", &n);
	printf("Este foi o input recebido: %d\n", n);
}

void ler_soma() {
	int a, b, c;
	printf("Insira a soma (no formato x+x=):\n");
	scanf("%d + %d =",&a, &b);
	c = a + b;
	printf("Soma de %d + %d: %d\n", a, b, c);
}

void ler_escrever_real() {
	float x;
	printf("Insira um numero real: ");
	scanf("%f", &x);
	printf("Este foi o input recebido: %f\n", x);
}

void ler_coordenada() {
	float y, z;
	printf("Insira as coordenadas (no formato (y.yyy,z.zzz) ): ");
	scanf(" (%f , %f )",&y, &z);
	printf("Esta foi a coordenada recebida: (%.3f, %.3f)\n", y, z);
}


int main() {
	ler_escrever_inteiro();
	ler_soma();
	ler_escrever_real();
	ler_coordenada();

}