#include <stdio.h>

int main(void)
{
  printf("Olá mundo.\n");

  return 0;
}