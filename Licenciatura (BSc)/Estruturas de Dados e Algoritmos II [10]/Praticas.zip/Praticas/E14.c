#include <stdio.h>

int main(void)
{
    int a; // i + ii
    int b, c; // iii
    double real; // v
    double x, y; // vii

    printf("inteiro: ");
    scanf("%d", &a);    // i
    printf("%d\n\n", a);    //  ii

    printf("a + b = \nsoma: ");
    scanf(" %d + %d =", &b, &c);    // iii
    printf("%d\n\n", a+b);    // iv

    printf("real: ");
    scanf("%lf", &real); // v
    printf("%f\n\n", real); // vi

    printf("(XX.xx , YY.yy) \ncoordenadas: ");
    scanf(" ( %lf , %lf )", &x, &y);  // vii
    printf("%.3lf, %.3lf\n", x, y);   // viii


    return 0;
}