#include <stdio.h>

int main(void) {
	int n=15180;
	int cont=0;
	for (int i=2; i<n; i++){
		if (n%i==0){
			printf("%d\n", i);
			cont++;
		}

	}
	printf("+ %d tem %d divisores\n", n, cont);
}




