// a. Versão recursiva
#include <stdio.h>

int maior(int x, int y)
{
  if(x > y) 
    return x;

  return y;
}

void ler_escrever()
{
  int x, y;

  printf("Introduza dois inteiros: ");
  scanf("%d %d", &x, &y);

  printf("O maior valor é %d.\n", maior(x, y));

}

int main(void)
{
  ler_escrever();

  return 0;
}




/* VP

  Devolve o maior inteiro entre A e B

int max(int a, int b)
{
  return a > b ? a : b;
}

int main(void)
{
  int n1, n2;

  printf("Introduza dois inteiros: ");
  scanf("%d %d", &n1, &n2);

  printf("O maior valor é %d.\n", max(n1, n2));

  return 0;
}

*/