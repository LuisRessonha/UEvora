#include <stdio.h>

void quadrado(int size)
{
  for (int i = 1; i <= size; ++i)
  {
    int j;

    for (j = 1; j < size; ++j)
      printf("%3d ", i * j);

    printf("%3d\n", i * j);
  }
}

int main(void)
{
  quadrado(20);
  return 0;
}