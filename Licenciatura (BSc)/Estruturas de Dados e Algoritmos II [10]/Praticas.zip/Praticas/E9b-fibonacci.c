// b. Iterativamente
#include <stdio.h>

void fibonacci(int size)
{
  int a = 0;
  int b = 1;
  int c = b;

  printf("%d %d", a, b);

  for(int i = 0; i < size-2; i++)
  {
    c = a + b;
    a = b;
    b = c;
    printf(" %d", c);
  }
  printf("\n");
}

int main(void)
{
  fibonacci(20);
  return 0;
}