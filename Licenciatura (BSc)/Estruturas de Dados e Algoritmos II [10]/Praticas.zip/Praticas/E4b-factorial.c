// b. Versão iterativa
#include <stdio.h>

int factorial(int num)
{
    int f = 1;

    while(num > 0)
    {
        f = f * num;
        num--;
    }
    
    return f;
}

int main(void)
{
    printf("%d! =  %d\n", 10, factorial(10));

    // Não dá o resultado correcto porque 20! > 2^31 - 1
    printf("%d! != %d\n", 20, factorial(20));

    // Não dá o resultado correcto porque 21! > 2^63 - 1
    printf("%d! != %d\n", 21, factorial(21));

    return 0;
}