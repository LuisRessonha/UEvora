#include <stdio.h>

// Função para a soma dos Maximos de cada subsequencia
void get_M(int n, int array[n], int M){
	long long soma = 0;
	for ( int i =0; i<n; i+=M){  // Loop que percorre todo o array
		int max = array[i];
			for ( int j=0; j<M; j++){ // Loop que percorre cada subsquencia
				if(max < array[i+j]){
					max = array[i+j];
				}

				// Se a proxima posicao a verificar nao existir no array o loop termina
				if (i+j+1>=n){ 
					break;
				}
			}
		soma += max; // resultado da soma dos maximos de cada subsquencia
	}
	printf("+ max %lld\n", soma);
}

// Função para a soma dos minimos de cada subsequencia
void get_m(int n, int array[n], int m){
	long long soma = 0;
	for ( int i=0; i<n; i+=m){ // Loop que percorre todo o array
		int min = array[i];
			for ( int j=0; j<m; j++){ // Loop que percorre cada subsquencia
				if(min > array[i+j]){
					min = array[i+j];
				}

				// Se a proxima posicao a verificar nao existir no array o loop termina
				if (i+j+1>=n){
					break;
				}
			}
		soma += min; // resultado da soma dos minimos de cada subsquencia
	}
	printf("+ min %lld\n", soma);
}

int main(){
	int n; // tamanho array
	scanf(" %d", &n);
	int array[n];
	int x;
	for (int i = 0; i < n; i++){ // Preenchimento do array
		scanf(" %d", &x);
		array[i]=x;
	}

	char m;
	int y; // tamanho da subsequencia pedida

	// Tamanho e tipo dos array onde serao guardados os M's o tamanhos das subsequencias
	char arrayInput_m[2*n]; 
	int arrayInput_y[2*n];

	int j=0;
	// Percorre o ficheiro de input ate na existirem mais dados para introduzir
	while(scanf(" %c %d", &m, &y ) != EOF){ 
		if (y==0){
			continue;
		}
		else{
			arrayInput_m[j]=m; // Guarda o m/M no array arrayInput_m
			arrayInput_y[j]=y; // Guarda o y no array arrayInput_y
			j++;
		}
	}

	for (int h = 0; h < j; h++)
	{
		m = arrayInput_m[h];
		y = arrayInput_y[h];

		if (m=='M'){ // Chama a funcao da soma dos maximos 
			get_M(n, array, y);
		}
		if (m=='m'){ // Chama a funcao da soma dos minimos
			get_m(n, array, y);
		}
	}
	return 0;
}