// a. Versão recursiva
#include <stdio.h>

int factorial(int num)
{
    if (num == 0)
        return 1;
    else
        return num * factorial(num - 1);
}

int main(void)
{
    printf("%d! =  %d\n", 10, factorial(10));

    // Não dá o resultado correcto porque 20! > 2^31 - 1
    printf("%d! != %d\n", 20, factorial(20));

    // Não dá o resultado correcto porque 21! > 2^63 - 1
    printf("%d! != %d\n", 21, factorial(21));

    return 0;
}
