#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>


int main(void){
	int n;
	scanf(" %d", &n);

	printf("%d", n);

	for (int i = 0; i < n; ++i){
		printf("\n");
			for (int l = 0; l < n; ++l){

				int r = rand() % 3;
				if (r == 0){
					printf("X");
				}
				else{
					printf(".");
				}	
			}
	}
	return 0;
}