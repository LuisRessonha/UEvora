#include <stdio.h>

int main(void)
{
  int max = 20;
  for (int i = 1; i <= max; ++i)
  {
    printf("%d", i);

    if (i != max)
      printf(" ");
  }
  printf("\n");
  return 0;


}


/* Resposta VP
//  3. E se fossemos um bocadinho mais longe do que no anterior, 
//  começando a implementar as funcionalidades do programa através de funções?

//  Escreve uma linha com os inteiros entre PRIMEIRO e ULTIMO, separados por um espaço.

//  Se PRIMEIRO > ULTIMO, só escreve PRIMEIRO.


#include <stdio.h>

void linha(int primeiro, int ultimo)
{
  int n = primeiro;

  while (n < ultimo)
    {
      printf("%d ", n);

      n++;
    }

  printf("%d\n", n);
}

int main(void)
{
  linha(1, 20);

  return 0;
}

 
*/