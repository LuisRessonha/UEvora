#include <stdio.h>

// feito
void criar_lab(int largura, int altura, char mapa[altura][largura]){
	for (int linha = 0; linha < altura; linha++){
		for (int coluna = 0; coluna < largura; coluna++){
			scanf(" %c", &mapa[linha][coluna]);
		}
	}
}

// feito
void print_sol(int largura, int altura, char mapa[altura][largura]){
	for (int linha = 0; linha < altura; linha++){
		for (int coluna = 0; coluna < largura; coluna++){
			printf("%c ", mapa[linha][coluna]);
		}
		printf("\n");
	}
}

// feito
void solve_lab(int largura, int altura, char mapa[altura][largura], int max_pontos, int caminho[2][max_pontos]){
	int atual, x, y;
	int pos = 0;
	while (atual != -1){
		y = caminho[0][pos];
		x = caminho[1][pos];

		mapa[y][x] = 'o';

		pos++;
		atual = caminho[0][pos];
	}
	print_sol(largura, altura, mapa);
}

// alguma coisa
void varios_caminhos(int largura, int altura, char mapa[altura][largura], int max_pontos, 
			int caminho[2][max_pontos], int size_caminho, int y, int x, int pos_anterior[2][1]){
	////////////////////////////////////////////////////////
printf("\ninicio while_coise\n");//////////////////////
printf("%d %d\n", y, x);//////////////////////////////
printf("%d\n", size_caminho);////////////////////////
printf("%d %d\n\n", caminho[0][size_caminho-1],/////
caminho[1][size_caminho-1]);///////////////////////
//////////////////////////////////////////////////
int drt = 0;
int esq = 0;
int cima = 0;
int baixo = 0;
int possivel = 0;
int voltar = 0;

			// canto superior esquerdo
			if (y == 0 && x == 0) {
				voltar = 0;
				if (mapa[y+1][x] == '.' && pos_anterior[0][0] != y+1) {
					printf("Baixo\n");
					baixo++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x+1] == '.' && pos_anterior[0][1] != x+1) {
					printf("Direita\n");
					drt++;
					possivel++;
					voltar = 1;
				}
				if (voltar == 0){
					return;
				}
			}

			// canto inferior esquerdo
			else if (y == altura - 1 && x == 0) {
				voltar = 0;
				if (mapa[y-1][x] == '.' && pos_anterior[0][0] != y-1) {
					printf("Cima\n");
					cima++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x+1] == '.' && pos_anterior[0][1] != x+1) {
					printf("Direita\n");
					drt++;
					possivel++;
					voltar = 1;
				}
				if (voltar == 0){
					return;
				}
			}

			// canto superior direito			
			else if (y == 0 && x == largura - 1) {
				voltar = 0;
				if (mapa[y+1][x] == '.' && pos_anterior[0][0] != y+1) {
					printf("Baixo\n");
					baixo++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x-1] == '.' && pos_anterior[0][1] != x-1) {
					printf("Esquerda\n");
					esq++;
					possivel++;
					voltar = 1;
				}
				if (voltar == 0){
					return;
				}
			}

			// canto inferior direito
			else if (y == altura - 1 && x == largura - 1) {
				voltar = 0;
				if (mapa[y-1][x] == '.' && pos_anterior[0][0] != y-1) {
					printf("Cima\n");
					cima++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x-1] == '.' && pos_anterior[0][1] != x-1) {
					printf("Esquerda\n");
					esq++;
					possivel++;
					voltar = 1;
				}
				if (voltar == 0){
					return;
				}
			}

			// primeira lilha menos cantos
			else if (y == 0 && x != largura - 1 && x != 0) {
				voltar = 0;
				if (mapa[y+1][x] == '.' && pos_anterior[0][0] != y+1) {
					printf("Baixo\n");
					baixo++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x-1] == '.' && pos_anterior[0][1] != x-1) {
					printf("Esquerda\n");
					esq++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x+1] == '.' && pos_anterior[0][1] != x+1) {
					printf("Direita\n");
					drt++;
					possivel++;
					voltar = 1;
				}
				if (voltar == 0){
					return;
				}
			}

			// ultima lilha menos cantos
			else if (y == altura-1 && x != largura - 1 && x != 0) {
				voltar = 0;
				if (mapa[y-1][x] == '.' && pos_anterior[0][0] != y-1) {
					printf("Cima\n");
					cima++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x-1] == '.' && pos_anterior[0][1] != x-1) {
					printf("Esquerda\n");
					esq++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x+1] == '.' && pos_anterior[0][1] != x+1) {
					printf("Direita\n");
					drt++;
					possivel++;
					voltar = 1;
				}
				if (voltar == 0){
					return;
				}
			}

			// primeira coluna menos cantos
			else if (x == 0 && y != altura - 1 && y != 0) {
				voltar = 0;
				if (mapa[y+1][x] == '.' && pos_anterior[0][0] != y+1) {
					printf("Baixo\n");
					baixo++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y-1][x] == '.' && pos_anterior[0][0] != y-1) {
					printf("Cima\n");
					cima++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x+1] == '.' && pos_anterior[0][1] != x+1) {
					printf("Direita\n");
					drt++;
					possivel++;
					voltar = 1;
				}
				if (voltar == 0){
					return;
				}
			}

			// ultima coluna menos cantos
			else if (x == 0 && y != altura - 1 && y != 0) {
				voltar = 0;
				if (mapa[y+1][x] == '.' && pos_anterior[0][0] != y+1) {
					printf("Baixo\n");
					baixo++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y-1][x] == '.' && pos_anterior[0][0] != y-1) {
					printf("Cima\n");
					cima++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x-1] == '.' && pos_anterior[0][1] != x-1) {
					printf("Esquerda\n");
					esq++;
					possivel++;
					voltar = 1;
				}
				if (voltar == 0){
					return;
				}
			}
			// centro
			else {
				voltar = 0;
				if (mapa[y+1][x] == '.' && pos_anterior[0][0] != y+1) {
					printf("Baixo\n");
					baixo++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y-1][x] == '.' && pos_anterior[0][0] != y-1) {
					printf("Cima\n");
					cima++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x-1] == '.' && pos_anterior[0][1] != x-1) {
					printf("Esquerda\n");
					esq++;
					possivel++;
					voltar = 1;
				}
				if (mapa[y][x+1] == '.' && pos_anterior[0][1] != x+1) {
					printf("Direita\n");
					drt++;
					possivel++;
					voltar = 1;
				}
				if (voltar == 0){
					return;
				}
			}
			if (possivel == 0 && y != 0 && x != 0){
				return;
			}
			if (possivel >= 2 && y != 0 && x != 0){
				if (cima == 1){
					varios_caminhos(largura, altura, mapa, max_pontos, caminho, size_caminho, y-1, x, pos_anterior);
				}
				if (baixo == 1){
					varios_caminhos(largura, altura, mapa, max_pontos, caminho, size_caminho, y+1, x, pos_anterior);
				}
				if (esq == 1){
					varios_caminhos(largura, altura, mapa, max_pontos, caminho, size_caminho, y, x-1, pos_anterior);
				}
				if (drt == 1){
					varios_caminhos(largura, altura, mapa, max_pontos, caminho, size_caminho, y, x+1, pos_anterior);
				}
			}


//////////////////////////////////////////////////
			if (drt == 1 && esq == 0 && cima == 0 && baixo == 0){
				pos_anterior[0][0] = y;
				pos_anterior[1][0] = x;
				x++;
				caminho[0][size_caminho] = y;
				caminho[1][size_caminho] = x;
				size_caminho++;

			}
			if (drt == 0 && esq == 1 && cima == 0 && baixo == 0){
				pos_anterior[0][0] = y;
				pos_anterior[1][0] = x;
				x--;
				caminho[0][size_caminho] = y;
				caminho[1][size_caminho] = x;
				size_caminho++;
			}
			if (drt == 0 && esq == 0 && cima == 1 && baixo == 0){
				pos_anterior[0][0] = y;
				pos_anterior[1][0] = x;
				y--;
				caminho[0][size_caminho] = y;
				caminho[1][size_caminho] = x;
				size_caminho++;
			}
			if (drt == 0 && esq == 0 && cima == 0 && baixo == 1){
				pos_anterior[0][0] = y;
				pos_anterior[1][0] = x;
				y++;
				caminho[0][size_caminho] = y;
				caminho[1][size_caminho] = x;
				size_caminho++;
			}
/////////////////////////////////////////////////////
printf("\n---------------------\n");
/////////////////////////////////////////////////////
	//
	varios_caminhos(largura, altura, mapa, max_pontos, caminho, size_caminho, y, x, pos_anterior);
	return;
}






/*---------------------------------------------------------------------------------*/
// procurar caminho
void procurar_caminho(int largura, int altura, char mapa[altura][largura]){
	int max_pontos = altura * largura;
	int caminho[2][max_pontos]; // matriz onde sao guardadas as coordenadas do caminho
	int size_caminho = 0; // tamanho do caminho
	int size_caminho_min = altura + largura - 1;
	int y = 0; // altura
	int x = 0; // lagura

	// Coloca todas as posicoes do array caminho a NULL
	for (int i = 0; i < max_pontos; i++) {
		caminho[0][i] = -1;
		caminho[1][i] = -1;
	}
	
	int pos_anterior[2][1];
	pos_anterior[0][0] = -1;
	pos_anterior[1][0] = -1;



	if (mapa[y][x] == '.'){
		caminho[0][size_caminho] = y;
		caminho[1][size_caminho] = x;
		pos_anterior[0][0] = y;
		pos_anterior[1][0] = x;
		size_caminho++;
		varios_caminhos(largura, altura, mapa, max_pontos, caminho, size_caminho, y, x, pos_anterior);
	}

	if (size_caminho <= size_caminho_min) {
		printf("+ sem caminho\n");
	}
	else if (y == altura - 1 && x == largura - 1){
		solve_lab(largura, altura, mapa, max_pontos, caminho);
	}
}
/*---------------------------------------------------------------------------------*/



int main(){
	int largura;
	int altura; // tamanho do mapa
	scanf(" %d %d\n", &largura, &altura);
	char mapa[altura][largura];

	criar_lab(largura, altura, mapa);

	// testes ///////////////////
	print_sol(largura, altura, mapa);
	printf("\n");
	/////////////////////////////*/


	procurar_caminho(largura, altura, mapa);



	return 0;
}