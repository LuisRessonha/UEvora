#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <math.h>


int main(void){
	int n;
	scanf(" %d", &n);

	printf("%d", n);

	for (int i = 0; i < n; ++i){
		printf("\n");
		if (i%2==0){
			for (int l = 0; l < n; ++l){
				//char linha = "X";
				if (l%2 == 0){
					printf("X");
				}
				else{
					printf(".");
				}	
			}
		}
		else{
			for (int j = 0; j < n; ++j){
					//char linha = "X";
					printf(".");	
			}
		}
	}
	return 0;
}