%Pesquisa não informada
%1. Considere o problema dos jarros de água: Tem 2 jarros de água com capacidade c1 e c2, pode realizar as seguintes acções com os jarros:


%estados
estado_inicial((0,0)).
estado_final((0,1)).

%capacidade
capacidade(c1,3).
capacidade(c2,2).

%op(Estado_atual,OP,Estado_seguinte,Custo)
op((A,B),encher(c1),(A1,B),1):- %encher c1
	capacidade(c1,A1),
	A \= A1.
op((A,B),encher(c2),(A,B1),1):- %encher c2
	capacidade(c2,B1),
	B \= B1.

op((A,B),despejar(c1),(0,B),1):- %despejar c1
	A \= 0.
op((A,B),despejar(c2),(A,0),1):- %despejar c2
	B \= 0.

op((A,B),despejar(c1,c2),(0,B1),1):- %despejar de c1 para c2 (totalmente)
	capacidade(c2,C),
	C >= A + B,
	B1 is A + B.
op((A,B),despejar(c1,c2),(A1,B1),1):- %despejar de c1 para c2 (parcialmente)
	capacidade(c2,C),
	C < A + B,
	R is C - B,
	A1 is A - R,
	B1 is C.

op((A,B),despejar(c1,c2),(A1,0),1):- %despejar de c2 para c1 (totalmente)
	capacidade(c1,C),
	C >= A + B,
	A1 is A + B.
op((A,B),despejar(c2,c1),(A1,B1),1):- %despejar de c2 para c1(parcialmente)
	capacidade(c1,C),
	C < A + B,
	R is C - A,
	B1 is B - R,
	A1 is C.


%representacao dos nos
%no(Estado,no_pai,Operador,Custo,Profundidade)

pesquisa_largura([no(E,Pai,Op,C,P)|_],no(E,Pai,Op,C,P)) :- 
	estado_final(E).
pesquisa_largura([E|R],Sol):- 
	expande(E,Lseg),
        insere_fim(Lseg,R,LFinal),
        pesquisa_largura(LFinal,Sol).

expande(no(E,Pai,Op,C,P),L):- 
	findall(no(En,no(E,Pai,Op,C,P), Opn, Cnn, P1),
                (op(E,Opn,En,Cn), P1 is P+1, Cnn is Cn+C),
                L).

pesquisa :-
	estado_inicial(S0),
	pesquisa_largura([no(S0,[],[],0,0)], S),
	write(S), nl.


insere_fim([],L,L).
insere_fim(L,[],L).
insere_fim(R,[A|S],[A|L]):- insere_fim(R,S,L).
