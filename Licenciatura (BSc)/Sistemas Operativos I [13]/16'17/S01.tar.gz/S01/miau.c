#include <stdio.h>

typedef struct pcb {
    int volei 
    int cinema
    int trajados
}
