#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main(void){
	pid_t pid = fork();
	int n = 5;
	const int x = n;
	int temp = 1;

	while (pid == 0){
		temp = temp * n;
		n--;
		if (n == 1){
			printf("Factorial de %d é: %d\n", x, temp);
			break;
		}
		pid = fork();
	}

}