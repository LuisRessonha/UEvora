#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define QUANTUM 4
#define MAX_READY 4
#define MEM_SIZE 300 

typedef struct PCB_ {

} pcb;

typedef struct queue {
    int ultima_lida;
    int lidas;
	struct node_ *next;
} node;

//Feito
node *node_new(User *user)
{
	node *n = malloc(sizeof(node));
    n->user = user;
    int ultima_lida = get_mensagens(user);
    int lidas;

	n->next = NULL;

	return n;
}


int main()
{
    return 0;
}